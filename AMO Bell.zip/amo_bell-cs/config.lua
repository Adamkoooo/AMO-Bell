Config = {}

Config.Dispatchsettings = 'ps-dispatch' -- 'ps-dispatch'

Config.Targetlocation = vector3(-292.4737, -1054.7540, 28.3378) -- Zde nastavte vaše souřadnice

Config.Cooldown = 300 -- Cooldown v sekundách (5 minut)