local ESX = nil
local lastInteraction = 0 -- Čas poslední interakce

Citizen.CreateThread(function()
    while ESX == nil do
        ESX = exports["es_extended"]:getSharedObject()
        Citizen.Wait(0)
    end
end)

-- Funkce pro vytvoření cíle
local function createTarget()
    -- Vytvoření cíle pomocí ox_target
    exports.ox_target:addSphereZone({
        coords = Config.Targetlocation,
        radius = 1.5, -- Poloměr cílové oblasti
        options = {
            {
                name = 'interact_with_target', -- Název akce
                icon = 'fas fa-bell', -- Ikona akce
                label = 'Zazvonit', -- Popis akce
                onSelect = function()
                    local currentTime = GetGameTimer() -- Získání aktuálního času v milisekundách
                    if (currentTime - lastInteraction) >= (Config.Cooldown * 1000) then
                        -- Odeslání dispatch zprávy při interakci
                        exports[Config.Dispatchsettings]:CustomAlert({
                            coords = Config.Targetlocation, -- Použití souřadnic z configu
                            message = "Důstojník požádán na recepci", -- Zpráva
                            dispatchCode = "Příjem hovoru", -- Kód dispatch
                            description = "Občan si zavolal na recepci strážníka.", -- Popis
                            radius = 0,
                            sprite = 64,
                            color = 2,
                            scale = 1.0,
                            length = 3,
                        })
                        -- Zobrazení notifikace
                        TriggerEvent('okokNotify:Alert', 'LSPD Recepce', 'Důstojník byl povolán na recepci.', 5000, 'info')
                        lastInteraction = currentTime -- Aktualizace času poslední interakce
                    else
                        -- Zobrazení notifikace, pokud je cooldown aktivní
                        local remainingTime = (Config.Cooldown * 1000) - (currentTime - lastInteraction)
                        TriggerEvent('okokNotify:Alert', 'LSPD Recepce', 'Musíte počkat ' .. math.ceil(remainingTime / 1000) .. ' sekund před dalším zavoláním.', 5000, 'error')
                    end
                end
            }
        }
    })
end

-- Hlavní funkce, která se spustí při načtení skriptu
Citizen.CreateThread(function()
    createTarget() -- Vytvoření cíle
end)