fx_version 'cerulean' -- nebo 'bodacious', podle verze FiveM, kterou používáte
game 'gta5'

author 'Adamkoo' -- Zde zadejte své jméno nebo jméno autora
description 'Skript pro dispatch a interakci s cílem'
version '1.0.0'

-- Závislosti
dependency 'ox_target' -- Závislost na ox_target
dependency 'ps-dispatch' -- Závislost na ps-dispatch
dependency 'okokNotify' -- Závislost na okokNotify

-- Skripty
client_script 'config.lua' -- Načtení konfiguračního souboru
client_script 'client.lua' -- Načtení klientského skriptu

lua54 'yes'